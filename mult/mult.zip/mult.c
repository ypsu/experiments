#line 48 "mult.nw"
#include <ctype.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#line 98 "mult.nw"
struct complex_num {
	double real;
	double imag;
};
#line 109 "mult.nw"
void iterative_fft(const struct complex_num *A,
	struct complex_num *Y, int n, double d);
#line 330 "mult.nw"
int rev(int k, int n)
{
	int r = 0;
	n /= 2;
	while (n > 0) {
		r = r*2 + k%2;
		k /= 2;
		n /= 2;
	}
	return r;
}
#line 344 "mult.nw"
void bit_reverse_copy(const struct complex_num *A,
	struct complex_num *Y, int n)
{
	int k;
	for (k = 0; k < n; ++k)
		Y[rev(k, n)] = A[k];
}
#line 474 "mult.nw"
int get_size(const char *fname)
{
	FILE *f;
	int sz;

	f = fopen(fname, "r");
	if (f == 0) {
		fprintf(stderr, "Couldn't open %s!\n", fname);
		exit(1);
	}
	for (sz = 0; sz >= 0 && isdigit(getc(f)); ++sz)
		;
	if (sz < 0) {
		fprintf(stderr, "File %s is too long!\n", fname);
		exit(1);
	}
	fclose(f);
	return sz;
}
#line 506 "mult.nw"
int next_two_power(int t)
{
	int k = 1;
	while (t > 0) {
		k *= 2;
		t /= 2;
	}
	return k;
}
#line 548 "mult.nw"
void read_file(const char *fname, int sz, struct complex_num *D)
{
	int rd;
	FILE *f;

	f = fopen(fname, "r");
	if (f == 0) {
		fprintf(stderr, "Couldn't open %s!\n", fname);
		exit(1);
	}

	rd = 0;
	while (rd < sz) {
		int c;
		c = getc(f);
		if (c == EOF || !isdigit(c)) {
			fprintf(stderr,
				"The file %s has changed!\n",
				fname);
		}

		rd += 1;
		D[sz-rd].real = c - '0';
	}
	fclose(f);
}
#line 364 "mult.nw"
int main(int argc, char **argv)
{
	int i; /* general purpose local variable */
	
#line 377 "mult.nw"
int n;
struct complex_num *A, *B, *C;
struct complex_num *AA, *BB, *CC;
#line 424 "mult.nw"
double carry;
#line 496 "mult.nw"
int len1, len2;
#line 534 "mult.nw"
char *data;
#line 368 "mult.nw"
	
#line 462 "mult.nw"
if (argc < 3) {
	fprintf(stderr, "Usage: %s filename1 filename2\n", argv[0]);
	exit(1);
}
#line 498 "mult.nw"
len1 = get_size(argv[1]);
len2 = get_size(argv[2]);
#line 521 "mult.nw"
n = next_two_power(len1 + len2 - 1);
if (n < 0) {
	fprintf(stderr, "The resulting number is too big!\n");
	exit(1);
}
#line 536 "mult.nw"
data = calloc(16, 6*n + 1);
A = (void*) ((long)(data + 15) & ~15);
B = A + n;
C = B + n;
AA = C + n;
BB = AA + n;
CC = BB + n;
#line 579 "mult.nw"
read_file(argv[1], len1, A);
read_file(argv[2], len2, B);
#line 369 "mult.nw"
	
#line 395 "mult.nw"
iterative_fft(A, AA, n, 1.0);
iterative_fft(B, BB, n, 1.0);
#line 410 "mult.nw"
for (i = 0; i < n; ++i) {
	/* we have to do complex multiplication */
	double a = AA[i].real, b = AA[i].imag;
	double c = BB[i].real, d = BB[i].imag;
	CC[i].real = a*c - b*d;
	CC[i].imag = a*d + b*c;
}
#line 401 "mult.nw"
iterative_fft(CC, C, n, -1.0);
for (i = 0; i < n; ++i) {
	C[i].real /= n;
	C[i].imag /= n;
}
#line 426 "mult.nw"
carry = 0.0;
for (i = 0; i < n; ++i) {
	C[i].real = floor(C[i].real + carry + 0.5); /* round */
	carry = floor(C[i].real / 10.0);
	C[i].real = fmod(C[i].real, 10.0);
}
#line 370 "mult.nw"
	
#line 591 "mult.nw"
for (i = n-1; i > 0 && (int) C[i].real == 0; --i)
	;
#line 595 "mult.nw"
for (; i >= 0; --i)
	printf("%0.0f", C[i].real);
puts("");
#line 587 "mult.nw"
free(data);
#line 371 "mult.nw"
	return 0;
}
