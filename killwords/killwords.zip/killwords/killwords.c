#include <assert.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_net.h>
#include <SDL/SDL_ttf.h>

#define HANDLE_CASE(x) \
	if (x) { \
		handle_case(#x, __func__, __FILE__, __LINE__); \
	}

void handle_case(const char *casestr, const char *function, const char *file, int line)
{
	printf("Unhandled case '%s'\n", casestr);
	printf("in function %s from %s:%d\n", function, file, line);
	printf("errno: %m\n");
	printf("SDL_GetError(): %s\n", SDL_GetError());
	printf("SDLNet_GetError(): %s\n", SDLNet_GetError());
	exit(1);
}

#define MAX_TEXT_SIZE 256
#define MAX_WORDS 1024
#define MAX_PLAYERS 4

bool g_should_quit;
bool g_draw_needed;
SDL_Surface *g_screen;
TTF_Font *g_font;
int g_font_lineskip;
enum color_names {
	COLOR_BLACK,
	COLOR_WHITE,
	COLOR_RED,
	COLOR_GREEN,
	COLOR_BLUE,
	COLOR_YELLOW,
	COLOR_PINK,
};
SDL_Color g_colors[] = {
	{.r =   0, .g =   0, .b =   0},
	{.r = 255, .g = 255, .b = 255},
	{.r = 255, .g =   0, .b =   0},
	{.r =   0, .g = 255, .b =   0},
	{.r =   0, .g =   0, .b = 255},
	{.r = 255, .g = 255, .b =   0},
	{.r = 255, .g =   0, .b = 255},
};
char g_hostname[MAX_TEXT_SIZE] = "localhost";
char g_wordlist_file[MAX_TEXT_SIZE] = "words-eng.txt";
int g_port = 3812;
enum gamestate { STATE_MAINMENU, STATE_LOBBY, STATE_INGAME, STATE_ERROR } g_state;
char g_error_message[MAX_TEXT_SIZE];
enum mainmenu_state {
	STATE_MAINMENU_IDLE,
	STATE_MAINMENU_HOSTNAME,
	STATE_MAINMENU_PORT,
	STATE_MAINMENU_WORDLIST
} g_mainmenu_state;
int g_max_word_length;
int g_available_score;

int g_word_count;
struct word {
	int x, y, w, h;
	int color;
	char text[MAX_TEXT_SIZE];
} g_words[MAX_WORDS];

int g_player_colors[MAX_PLAYERS] = {
	COLOR_RED,
	COLOR_YELLOW,
	COLOR_GREEN,
	COLOR_PINK,
};

int g_player_count;
int g_this_player; // the current instance's player ID
struct player {
	int score;
	char address[MAX_TEXT_SIZE];
	char text[MAX_TEXT_SIZE];
} g_players[MAX_PLAYERS];

enum net_command_type {
	NETCMD_SET_PLAYER_ID,
	NETCMD_ADD_WORD,
	NETCMD_ADD_PLAYER,
	NETCMD_COMMENCE_GAME,
	NETCMD_KEYPRESS,
};

struct netcmd {
	enum net_command_type type;
	int val;
};

struct server_info {
	int player_count;

	TCPsocket listener;
	SDLNet_SocketSet listener_set;

	TCPsocket clients[MAX_PLAYERS];
	SDLNet_SocketSet clients_set[MAX_PLAYERS];
} g_server;

TCPsocket g_server_conn;
SDLNet_SocketSet g_server_connset;

// Hack: SDLNet_TCP_Recv isn't conforming to its documentation
// (documentation retrieved in 2012 February, bug reported)
int recv_all(TCPsocket socket, void *buffer, int sz)
{
	int read = 0;
	int rem = sz;
	while (rem > 0 && (read = SDLNet_TCP_Recv(socket, buffer, rem)) > 0) {
		buffer += read;
		rem -= read;
	}
	if (read == -1)
		return -1;
	return sz - rem;
}

int character_count(const char *text)
{
	uint8_t *p = (uint8_t*) text;
	int cnt = 0;
	while (*p != 0) {
		cnt += 1;
		if ((*p & 0x80) == 0) {
			p += 1;
		} else if ((*p & 0xE0) == 0xC0) {
			p += 2;
		} else if ((*p & 0xF0) == 0xE0) {
			p += 3;
		} else {
			HANDLE_CASE("unhandled unicode character");
		}
	}
	return cnt;
}

void get_text_size(const char *text, int *w, int *h)
{
	HANDLE_CASE(TTF_SizeUTF8(g_font, text, w, h) == -1);
}

void draw_text(int x, int y, int color, const char *text)
{
	SDL_Surface *text_surface;
	text_surface = TTF_RenderUTF8_Shaded(g_font, text,
			g_colors[color], g_colors[COLOR_BLACK]);
	HANDLE_CASE(text_surface == NULL);
	SDL_Rect dst_rect = {.x = x, .y = y};
	SDL_BlitSurface(text_surface, NULL, g_screen, &dst_rect);
	SDL_FreeSurface(text_surface);
}

void draw_fmt_text(int x, int y, int color, const char *fmt, ...)
{
	va_list ap;
	va_start(ap, fmt);
	char buf[MAX_TEXT_SIZE];
	int needed = vsnprintf(buf, MAX_TEXT_SIZE, fmt, ap);
	HANDLE_CASE(needed >= MAX_TEXT_SIZE);
	va_end(ap);
	draw_text(x, y, color, buf);
}

void send_netcmd(TCPsocket *socket, const struct netcmd *cmd)
{
	if (*socket == NULL) return;

	char buf[4];
	HANDLE_CASE(cmd->type > 0xFF);
	HANDLE_CASE(cmd->val > 0xFFFFFF);
	SDLNet_Write32(cmd->val | (cmd->type << 24), buf);
	int written = SDLNet_TCP_Send(*socket, buf, 4);
	if (written < 4) {
		puts("a peer has disconnected");
		SDLNet_TCP_Close(*socket);
		*socket = NULL;
	}
}

bool recv_netcmd(TCPsocket *socket, struct netcmd *cmd)
{
	if (*socket == NULL) return false;

	char buf[4];
	int received = recv_all(*socket, buf, 4);
	if (received < 4) {
		puts("a peer has disconnected");
		SDLNet_TCP_Close(*socket);
		*socket = NULL;
		return false;
	}
	Uint32 n = SDLNet_Read32(buf);
	cmd->type = n >> 24;
	cmd->val = n & 0xFFFFFF;
	return true;
}

void server_distribute_buffer(const char *buf, int size)
{
	for (int i = 0; i < g_server.player_count; ++i) {
		TCPsocket sock = g_server.clients[i];
		if (sock == NULL) continue;
		int written = SDLNet_TCP_Send(sock, buf, size);
		if (written < size) {
			puts("a peer has disconnected");
			SDLNet_TCP_Close(sock);
			g_server.clients[i] = NULL;
		}
	}
}

void server_distribute_netcmd(struct netcmd *cmd)
{
	for (int i = 0; i < g_server.player_count; ++i) {
		send_netcmd(&g_server.clients[i], cmd);
	}
}

void stop_all_network(void)
{
	if (g_server.listener != NULL) {
		SDLNet_TCP_Close(g_server.listener);
		g_server.listener = NULL;
	}
	if (g_server.listener_set != NULL) {
		SDLNet_FreeSocketSet(g_server.listener_set);
		g_server.listener_set = NULL;
	}

	for (int i = 0; i < MAX_PLAYERS; ++i) {
		if (g_server.clients[i] != NULL) {
			SDLNet_TCP_Close(g_server.clients[i]);
			g_server.clients[i] = NULL;
		}
		if (g_server.clients_set[i] != NULL) {
			SDLNet_FreeSocketSet(g_server.clients_set[i]);
			g_server.clients_set[i] = NULL;
		}
	}

	if (g_server_conn != NULL) {
		SDLNet_TCP_Close(g_server_conn);
		g_server_conn = NULL;
	}
	if (g_server_connset != NULL) {
		SDLNet_FreeSocketSet(g_server_connset);
		g_server_connset = NULL;
	}
}

void connect_to_server(void)
{
	HANDLE_CASE(SDL_FillRect(g_screen, NULL, 0) == -1);
	draw_text(100, 100, COLOR_WHITE, "connecting");
	HANDLE_CASE(SDL_Flip(g_screen) == -1);

	IPaddress ip;
	if (SDLNet_ResolveHost(&ip, g_hostname, g_port) == -1) {
		snprintf(g_error_message, MAX_TEXT_SIZE-1, "Couldn't resolve '%s:%d'!",
				g_hostname, g_port);
		g_state = STATE_ERROR;
		return;
	}
	g_server_conn = SDLNet_TCP_Open(&ip);
	if (g_server_conn == NULL) {
		snprintf(g_error_message, MAX_TEXT_SIZE-1, "Couldn't connect to '%s:%d': %s",
				g_hostname, g_port, SDL_GetError());
		g_state = STATE_ERROR;
		return;
	}

	HANDLE_CASE(SDL_FillRect(g_screen, NULL, 0) == -1);
	draw_text(100, 100, COLOR_WHITE, "connected, receiving game data");
	HANDLE_CASE(SDL_Flip(g_screen) == -1);

	g_server_connset = SDLNet_AllocSocketSet(1);
	HANDLE_CASE(g_server_connset == NULL);
	HANDLE_CASE(SDLNet_TCP_AddSocket(g_server_connset, g_server_conn) == -1);
}

void start_server(void)
{
	IPaddress ip;

	HANDLE_CASE(SDLNet_ResolveHost(&ip, NULL, g_port) == -1);

	g_server.listener = SDLNet_TCP_Open(&ip);
	HANDLE_CASE(g_server.listener == NULL);

	g_server.listener_set = SDLNet_AllocSocketSet(1);
	HANDLE_CASE(g_server.listener_set == NULL);
	HANDLE_CASE(SDLNet_TCP_AddSocket(g_server.listener_set, g_server.listener) == -1);
}

void update_server(void)
{
	bool check_listener = true;
	check_listener = check_listener && g_server.listener != NULL;
	check_listener = check_listener && g_state == STATE_LOBBY;
	check_listener = check_listener && g_server.player_count < MAX_PLAYERS;
	if (check_listener) {
		int active = SDLNet_CheckSockets(g_server.listener_set, 0);
		HANDLE_CASE(active == -1);
		if (active == 1) {
			int id = g_server.player_count++;
			g_server.clients[id] = SDLNet_TCP_Accept(g_server.listener);
			g_server.clients_set[id] = SDLNet_AllocSocketSet(1);
			HANDLE_CASE(g_server.clients_set[id] == NULL);
			int res;
			res = SDLNet_TCP_AddSocket(g_server.clients_set[id], g_server.clients[id]);
			HANDLE_CASE(res == -1);

			struct netcmd cmd;
			cmd.type = NETCMD_SET_PLAYER_ID;
			cmd.val = id;
			send_netcmd(&g_server.clients[id], &cmd);

			IPaddress *peer_address = SDLNet_TCP_GetPeerAddress(g_server.clients[id]);
			HANDLE_CASE(peer_address == NULL);
			const char *hostname = SDLNet_ResolveIP(peer_address);
			const char *fmt;
			if (hostname == NULL)
				fmt = "%d.%d.%d.%d:%d";
			else
				fmt = "%d.%d.%d.%d:%d (%s)";
			Uint32 a = peer_address->host;
			Uint32 p = peer_address->port;
			p = ((p&0xFF)<<8) | (p >> 8);
			snprintf(g_players[id].address, MAX_TEXT_SIZE-1, fmt,
					(a) & 0xFF,
					(a>>8) & 0xFF,
					(a>>16) & 0xFF,
					(a>>24) & 0xFF,
					p,
					hostname);

			for (int i = 0; i < g_server.player_count-1; ++i) {
				cmd.type = NETCMD_ADD_PLAYER;
				cmd.val = strlen(g_players[i].address);
				send_netcmd(&g_server.clients[id], &cmd);
				int written = SDLNet_TCP_Send(g_server.clients[id],
					g_players[i].address, cmd.val);
				if (written < cmd.val) {
					puts("client disconnected while initial handshake");
					SDLNet_TCP_Close(g_server.clients[id]);
					g_server.clients[id] = NULL;
					break;
				}
			}

			cmd.type = NETCMD_ADD_PLAYER;
			cmd.val = strlen(g_players[id].address);
			server_distribute_netcmd(&cmd);
			server_distribute_buffer(g_players[id].address, cmd.val);

			if (g_server.clients[id] != NULL && id != 0) {
				for (int i = 0; i < g_word_count; ++i) {
					cmd.type = NETCMD_ADD_WORD;
					cmd.val = strlen(g_words[i].text);
					send_netcmd(&g_server.clients[id], &cmd);
					char buf[4];
					assert(g_words[i].x >= 0 && g_words[i].x < 1000);
					assert(g_words[i].y >= 0 && g_words[i].y < 1000);
					SDLNet_Write16(g_words[i].x, buf);
					SDLNet_Write16(g_words[i].y, buf+2);
					int written = 0;
					written += SDLNet_TCP_Send(g_server.clients[id], buf, 4);
					written += SDLNet_TCP_Send(g_server.clients[id],
							g_words[i].text, cmd.val);
					if (written < cmd.val+4) {
						puts("client disconnected while sending words");
						SDLNet_TCP_Close(g_server.clients[id]);
						g_server.clients[id] = NULL;
						break;
					}
				}
			}
		}
	}

	for (int i = 0; i < g_server.player_count; ++i) {
		if (g_server.clients[i] == NULL) continue;
		int active;
		while ((active = SDLNet_CheckSockets(g_server.clients_set[i], 0)) == 1) {
			char buf[4];
			int read = recv_all(g_server.clients[i], buf, 4);
			if (read < 4) {
				puts("a client has disconnected");
				SDLNet_TCP_Close(g_server.clients[i]);
				g_server.clients[i] = NULL;
				break;
			}
			server_distribute_buffer(buf, 4);
		}
		HANDLE_CASE(active == -1);
	}
}

void handle_player_input(int player, int codepoint);

void update_client(void)
{
	if (g_server_conn == NULL) return;
	int active;
	while (g_server_conn != NULL && (active = SDLNet_CheckSockets(g_server_connset, 0)) == 1) {
		struct netcmd netcmd;
		if (!recv_netcmd(&g_server_conn, &netcmd)) break;
		switch (netcmd.type) {
		case NETCMD_SET_PLAYER_ID:
			HANDLE_CASE(g_state != STATE_LOBBY);
			g_this_player = netcmd.val;
			break;
		case NETCMD_ADD_WORD: {
			HANDLE_CASE(g_state != STATE_LOBBY);
			int length = netcmd.val;
			HANDLE_CASE(length >= MAX_TEXT_SIZE);
			char buf[4];
			int read = 0;
			read += recv_all(g_server_conn, buf, 4);
			read += recv_all(g_server_conn, g_words[g_word_count].text, length);
			if (read != length+4) {
				puts("server disconnected while receiving words");
				SDLNet_TCP_Close(g_server_conn);
				g_server_conn = NULL;
				break;
			}
			struct word *w = &g_words[g_word_count++];
			w->text[length] = 0;
			w->color = COLOR_WHITE;
			w->x = SDLNet_Read16(buf);
			w->y = SDLNet_Read16(buf+2);
			HANDLE_CASE(w->x > 1000 || w->y > 1000);
			int cc = character_count(w->text);
			g_available_score += cc;
			if (cc > g_max_word_length) g_max_word_length = cc;
			if (g_word_count >= 2)
				HANDLE_CASE(strcmp(g_words[g_word_count-2].text, w->text) >= 0);
			break;
		}
		case NETCMD_ADD_PLAYER: {
			HANDLE_CASE(g_state != STATE_LOBBY);
			g_draw_needed = true;
			int address_size = netcmd.val;
			HANDLE_CASE(address_size >= MAX_TEXT_SIZE);
			int read = recv_all(g_server_conn,
					g_players[g_player_count].address, address_size);
			if (read < address_size) {
				puts("server disconnected while initial handshake");
				SDLNet_TCP_Close(g_server_conn);
				g_server_conn = NULL;
				break;
			}
			g_players[g_player_count].address[address_size] = 0;

			g_player_count += 1;
			break;
		}
		case NETCMD_COMMENCE_GAME:
			HANDLE_CASE(g_state != STATE_LOBBY);
			g_draw_needed = true;
			g_state = STATE_INGAME;
			break;
		case NETCMD_KEYPRESS: {
			g_draw_needed = true;
			int player = netcmd.val >> 16;
			int codepoint = netcmd.val & 0xFFFF;
			HANDLE_CASE(player < 0 || player >= g_player_count);
			handle_player_input(player, codepoint);
			break;
		}
		default:
			HANDLE_CASE("unhandled case");
			break;
		}
	}
	HANDLE_CASE(active == -1);
}

void draw_ingame_words(void)
{
	for (int i = 0; i < g_word_count; ++i) {
		struct word *w = &g_words[i];
		draw_text(w->x, w->y, w->color, w->text);
	}
}

void draw_ingame_player_stats(int player, int x, int y)
{
	if (player >= g_player_count) return;
	struct player *p = &g_players[player];
	draw_fmt_text(x, y, g_player_colors[player], "player %d: score=%d, word=%s",
			player, p->score, p->text);
}

void draw_ingame_statusbar(void)
{
	if (g_available_score != 0) {
		draw_fmt_text(0, 600-g_font_lineskip, COLOR_WHITE,
				"available score: %d", g_available_score);
	} else {
		int winner = 0;
		for (int i = 1; i < g_player_count; ++i) {
			if (g_players[i].score > g_players[winner].score)
				winner = i;
		}
		draw_fmt_text(0, 600-g_font_lineskip, g_player_colors[winner],
				"Game over! The winner is Player %d! Press Escape to quit!",
				winner);
	}

	draw_ingame_player_stats(0, 0, 600-3*g_font_lineskip);
	draw_ingame_player_stats(1, 0, 600-2*g_font_lineskip);
	draw_ingame_player_stats(2, 400, 600-3*g_font_lineskip);
	draw_ingame_player_stats(3, 400, 600-2*g_font_lineskip);
}

void draw_ingame(void)
{
	draw_ingame_words();
	SDL_Rect dest_rect = {
		.x = 0,
		.y = 600 - 3*g_font_lineskip-1,
		.w = 800,
		.h = 1
	};
	Uint32 color = SDL_MapRGB(g_screen->format, 255, 255, 255);
	HANDLE_CASE(SDL_FillRect(g_screen, &dest_rect, color) == -1);
	draw_ingame_statusbar();
}

bool intersects_with_another_word(const struct word *w)
{
	int x1 = w->x;
	int x2 = w->x + w->w + 10;
	int y1 = w->y;
	int y2 = w->y + w->h;
	for (int i = 0; i < g_word_count; ++i) {
		const struct word *v = &g_words[i];
		bool crosses_x = false, crosses_y = false;
		crosses_x = crosses_x || (v->x <= x1 && x1 <= v->x+v->w+10);
		crosses_x = crosses_x || (x1 <= v->x && v->x <= x2);
		crosses_y = crosses_y || (v->y <= y1 && y1 <= v->y+v->h);
		crosses_y = crosses_y || (y1 <= v->y && v->y <= y2);
		if (crosses_x && crosses_y) return true;
		if (strcmp(w->text, v->text) == 0) return true;
	}
	return false;
}

bool add_word(FILE *f, long pos)
{
	HANDLE_CASE(g_word_count >= MAX_WORDS);
	HANDLE_CASE(fseek(f, pos, SEEK_SET) == -1);
	while (getc(f) != '\n') continue;
	int ch;
	int sz = 0;
	struct word *w = &g_words[g_word_count];
	while ((ch = getc(f)) != '\n') {
		if (ch == EOF) return false;
		if (ch == '\r') continue;
		w->text[sz++] = ch;
		HANDLE_CASE(sz >= MAX_TEXT_SIZE/2);
	}
	w->text[sz] = 0;
	w->color = COLOR_WHITE;
	get_text_size(w->text, &w->w, &w->h);

	for (int i = 0; i < 20; ++i) {
		w->x = rand() % (800 - w->w - 1);
		w->y = rand() % (600 - w->h - 1 - 3*g_font_lineskip);
		if (!intersects_with_another_word(w)) {
			g_word_count += 1;
			return true;
		}
	}
	return false;
}

int cmp_words(const void *a, const void *b)
{
	const struct word *wa = a;
	const struct word *wb = b;
	return strcmp(wa->text, wb->text);
}

void generate_words(void)
{
	FILE *f = fopen(g_wordlist_file, "r");
	HANDLE_CASE(f == NULL);
	HANDLE_CASE(fseek(f, 0, SEEK_END) == -1);
	long size = ftell(f);
	HANDLE_CASE(size == -1);

	g_max_word_length = 0;
	g_available_score = 0;
	while (true) {
		int tries;
		for (tries = 0; tries < 10; ++tries) {
			if (add_word(f, rand() % size)) break;
		}
		if (tries == 10) break;
		int length = character_count(g_words[g_word_count-1].text);
		g_available_score += length;
		if (length > g_max_word_length) g_max_word_length = length;
	}

	fclose(f);
	qsort(g_words, g_word_count, sizeof g_words[0], cmp_words);
}

void init_lobby(void)
{
	g_word_count = 0;
	g_max_word_length = 0;
	g_available_score = 0;
	g_player_count = 0;
	g_this_player = -1;
	memset(g_players, 0, sizeof g_players);
	memset(g_words, 0, sizeof g_words);
}

void init_host(void)
{
	generate_words();
	g_server.player_count = 0;
	start_server();
}

bool wordlist_exists(void)
{
	FILE *f = fopen(g_wordlist_file, "r");
	if (f == NULL) return false;
	fclose(f);
	return true;
}

void draw_menu(void)
{
	int y = 100;
	draw_text(100, y, COLOR_WHITE, "1) new game");
	y += g_font_lineskip;
	draw_text(100, y, COLOR_WHITE, "2) join game");
	y += g_font_lineskip;

	if (g_mainmenu_state == STATE_MAINMENU_HOSTNAME) {
		draw_fmt_text(100, y, COLOR_YELLOW, "X) hostname: %s|", g_hostname);
	} else {
		draw_fmt_text(100, y, COLOR_WHITE, "3) hostname: %s", g_hostname);
	}
	y += g_font_lineskip;

	if (g_mainmenu_state == STATE_MAINMENU_PORT) {
		draw_fmt_text(100, y, COLOR_YELLOW, "X) port number: %d|", g_port);
	} else {
		draw_fmt_text(100, y, COLOR_WHITE, "4) port number: %d", g_port);
	}
	y += g_font_lineskip;

	const char *wordlist_warning = wordlist_exists() ? "" : "[can't open]";
	if (g_mainmenu_state == STATE_MAINMENU_WORDLIST) {
		draw_fmt_text(100, y, COLOR_YELLOW, "X) wordlist: %s| %s",
				g_wordlist_file, wordlist_warning);
	} else {
		draw_fmt_text(100, y, COLOR_WHITE, "5) wordlist: %s %s",
				g_wordlist_file, wordlist_warning);
	}
	y += g_font_lineskip;

	draw_text(100, y, COLOR_WHITE, "q) quit");
	y += g_font_lineskip;
	y += g_font_lineskip;
	draw_text(100, y, COLOR_WHITE, "Press 1 to start/host the game!");
}

void draw_lobby(void)
{
	int y = 100;
	draw_text(100, y, COLOR_WHITE, "THE LOBBY");
	if (g_this_player == 0) {
		y += g_font_lineskip;
		draw_text(100, y, COLOR_WHITE, "press ENTER when the game can start");
	}
	y += 2*g_font_lineskip;

	for (int i = 0; i < g_player_count; ++i) {
		draw_fmt_text(100, y, g_player_colors[i], "player %d is waiting [%s]", i,
				g_players[i].address);
		y += g_font_lineskip;
	}
}

void draw_screen(void)
{
	HANDLE_CASE(SDL_FillRect(g_screen, NULL, 0) == -1);
	if (g_state == STATE_MAINMENU) {
		draw_menu();
	} else if (g_state == STATE_LOBBY) {
		draw_lobby();
	} else if (g_state == STATE_INGAME) {
		draw_ingame();
	} else if (g_state == STATE_ERROR) {
		draw_text(100, 100, COLOR_WHITE, g_error_message);
	}

	HANDLE_CASE(SDL_Flip(g_screen) == -1);
}

void edit_text(char *text, int codepoint, bool append_allowed)
{
	int text_length = (int) strlen(text);
	if (codepoint == 27) {
		g_mainmenu_state = STATE_MAINMENU_IDLE;
	} else if (codepoint == 8) {
		if (text_length != 0) {
			if ((int) (uint8_t) text[text_length-1] < 128) {
				text_length -= 1;
			} else {
				uint8_t *last = (uint8_t*) &text[text_length-1];
				while (((*last) & 0xC0) != 0xC0) {
					text_length -= 1;
					last -= 1;
				}
				text_length -= 1;
				assert(text_length >= 0);
			}
			text[text_length] = 0;
		}
	} else if (text_length < MAX_TEXT_SIZE - 8 && append_allowed) {
		int cp = codepoint;
		if (cp <= 0x007F) {
			text[text_length++] = cp;
		} else if (cp < 0x07FF) {
			text[text_length++] = 0xC0 | (cp >> 6);
			text[text_length++] = 0x80 | (cp & 0x3F);
		} else if (cp < 0xFFFF) {
			text[text_length++] = 0xe0 | (cp >> 12);
			text[text_length++] = 0x80 | ((cp >> 6) & 0x3F);
			text[text_length++] = 0x80 | (cp & 0x3F);
		} else {
			HANDLE_CASE("missing unicode handling");
		}
		text[text_length] = 0;
	}
}

void handle_mainmenu_keysym(const SDL_keysym *keysym)
{
	int cp = keysym->unicode;
	if (g_mainmenu_state == STATE_MAINMENU_IDLE) {
		if (cp == '1') {
			if (wordlist_exists()) {
				g_state = STATE_LOBBY;
				init_lobby();
				init_host();
				connect_to_server();
			} else {
				g_mainmenu_state = STATE_MAINMENU_WORDLIST;
			}
		} else if (cp == '2') {
			g_state = STATE_LOBBY;
			init_lobby();
			connect_to_server();
		} else if (cp == '3') {
			g_mainmenu_state = STATE_MAINMENU_HOSTNAME;
		} else if (cp == '4') {
			g_mainmenu_state = STATE_MAINMENU_PORT;
		} else if (cp == '5') {
			g_mainmenu_state = STATE_MAINMENU_WORDLIST;
		} else if (cp == 'q') {
			g_should_quit = true;
		}
	} else if (g_mainmenu_state == STATE_MAINMENU_PORT) {
		if (cp == 13 || cp == 27) {
			g_mainmenu_state = STATE_MAINMENU_IDLE;
		} else if (cp == 8) {
			g_port /= 10;
		} else if ('0' <= cp && cp <= '9') {
			int val = cp - '0';
			int newport = g_port*10 + val;
			if (newport < 32768) g_port = newport;
		}
	} else {
		bool text_editing = false;
		text_editing = text_editing || g_mainmenu_state == STATE_MAINMENU_HOSTNAME;
		text_editing = text_editing || g_mainmenu_state == STATE_MAINMENU_WORDLIST;
		assert(text_editing);
		if (cp == 13 || cp == 27) {
			g_mainmenu_state = STATE_MAINMENU_IDLE;
		} else if (g_mainmenu_state == STATE_MAINMENU_HOSTNAME) {
			edit_text(g_hostname, cp, true);
		} else {
			edit_text(g_wordlist_file, cp, true);
		}
	}
}

int cmp_text_and_word(const void *text_p, const void *word_p)
{
	const char *a = text_p;
	const struct word *w = word_p;
	return strcmp(a, w->text);
}

void handle_player_input(int player, int codepoint)
{
	struct player *p = &g_players[player];
	int text_length = character_count(p->text);
	if (codepoint == 27) {
		p->text[0] = 0;
	} else if (codepoint == 13) {
		struct word *match = bsearch(p->text, g_words, g_word_count,
				sizeof g_words[0], cmp_text_and_word);
		if (match != NULL && match->color == COLOR_WHITE) {
			p->score += text_length;
			g_available_score -= text_length;
			p->text[0] = 0;
			match->color = g_player_colors[player];
		}
	} else {
		bool append_allowed = (text_length < g_max_word_length+10) ? true : false;
		edit_text(p->text, codepoint, append_allowed);
	}
}

void handle_ingame_keysym(const SDL_keysym *keysym)
{
	int codepoint = keysym->unicode;
	HANDLE_CASE(codepoint > 0xFFFF);
	if (codepoint == 27 && g_available_score == 0) {
		stop_all_network();
		g_state = STATE_MAINMENU;
	}
	struct netcmd cmd;
	cmd.type = NETCMD_KEYPRESS;
	cmd.val = (g_this_player << 16) | codepoint;
	send_netcmd(&g_server_conn, &cmd);
}

void handle_lobby_keysym(const SDL_keysym *keysym)
{
	int codepoint = keysym->unicode;
	if (codepoint == 27) {
		stop_all_network();
		g_state = STATE_MAINMENU;
	} else if (codepoint == 13) {
		if (g_this_player == 0) {
			struct netcmd cmd = {.type = NETCMD_COMMENCE_GAME};
			send_netcmd(&g_server_conn, &cmd);
			if (g_server.listener != NULL) {
				SDLNet_TCP_Close(g_server.listener);
				g_server.listener = NULL;
			}
		}
	}
}

void handle_keysym(const SDL_keysym *keysym)
{
	g_draw_needed = true;
	if (g_state == STATE_MAINMENU) {
		handle_mainmenu_keysym(keysym);
	} else if (g_state == STATE_LOBBY) {
		handle_lobby_keysym(keysym);
	} else if (g_state == STATE_INGAME) {
		handle_ingame_keysym(keysym);
	} else if (g_state == STATE_ERROR) {
		if (keysym->unicode == 27) {
			g_state = STATE_MAINMENU;
		}
	}
}

void update_game(void)
{
	update_server();
	update_client();
	if (g_draw_needed) {
		draw_screen();
		g_draw_needed = false;
	}
}

#undef main
int main(int argc, char **argv)
{
	srand(time(NULL));
	int res = SDL_Init(SDL_INIT_VIDEO | SDL_INIT_TIMER);
	HANDLE_CASE(res == -1);

	int flags = SDL_HWSURFACE | SDL_DOUBLEBUF;
	g_screen = SDL_SetVideoMode(800, 600, 32, flags);
	HANDLE_CASE(g_screen == NULL);
	SDL_EnableUNICODE(1);

	SDL_WM_SetCaption("Killwords!", NULL);

	HANDLE_CASE(TTF_Init() == -1);
	g_font = TTF_OpenFont("DejaVuSans.ttf", 12);
	HANDLE_CASE(g_font == NULL);
	g_font_lineskip = TTF_FontLineSkip(g_font) + 1;

	HANDLE_CASE(SDLNet_Init() == -1);

	draw_screen();
	while (!g_should_quit) {
		SDL_Event event;
		while (SDL_PollEvent(&event) != 0) {
			if (event.type == SDL_QUIT) {
				g_should_quit = true;
			} else if (event.type == SDL_KEYDOWN) {
				handle_keysym(&event.key.keysym);
			}
		}
		update_game();
		SDL_Delay(10);
	}

	SDLNet_Quit();
	TTF_Quit();
	SDL_Quit();
	return 0;
}
