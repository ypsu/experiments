#include <assert.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef __unix__
#include <signal.h>
#endif

#include <SDL/SDL.h>
#include <SDL/SDL_net.h>
#include <SDL/SDL_ttf.h>

int MAX_CLIENTS = 2;
#define ROWS 12
#define COLS 10
#define MAX_GAMESTRING_LEN 32

int CURRENT_PLAYER = 0;

IPaddress g_currentIP;

char g_gameString[ROWS][COLS][MAX_GAMESTRING_LEN+1];
int g_playerPositions[ROWS][COLS][4];
int g_playerOwnage[ROWS][COLS];
int g_fieldStrength[ROWS][COLS];

/* server works like a demultiplexer:
   a client submits his keystrokes and those are distributed
   to everyone */
void RunServer();

/* a client submits his keystrokes to the server
   the actual gamedata will be updated only with the data
   from the server */
void RunClient();

void SetUpGameState();
void RenderGame();
void ProcessPlayerInput(int player, int ch);

/* make sure that we aren't rendering the same thing
   over and over when nothing happened */
int needRendering = 1;

#undef main

int main(int argc_, char **argv_)
{
	char networkType;
	char *host;
	int port;
	int lastnum;

	if (argc_ != 5) {
		puts("Usage: game S|C host port maxclient|current_player(0..3)");
		puts("S - server, C - client");
		puts("");
		return 0;
	}

	networkType = argv_[1][0];
	host = argv_[2];
	port = atoi(argv_[3]);
	lastnum = atoi(argv_[4]);

	if (networkType != 'S' && networkType != 'C') {
		puts("The first parameter must be 'C' or 'S'!");
		puts("");
		return 0;
	}

	if (SDL_Init(SDL_INIT_AUDIO | SDL_INIT_VIDEO | SDL_INIT_TIMER) == -1) {
		printf("SDL_Init: %s\n", SDL_GetError());
		return 1;
	}
	atexit(SDL_Quit);
#ifdef __unix__
	signal(SIGINT, SIG_DFL);
#endif

	if (SDLNet_Init() == -1) {
		printf("SDLNet_Init: %s\n", SDLNet_GetError());
	}
	atexit(SDLNet_Quit);

	/* is it server or client type? */
	if (networkType == 'S') {
		MAX_CLIENTS = lastnum;
		SDLNet_ResolveHost(&g_currentIP, 0, port);
	}
	else {
		CURRENT_PLAYER = lastnum;
		SDLNet_ResolveHost(&g_currentIP, host, port);
	}

	if (g_currentIP.host == INADDR_NONE) {
		printf("Error connecting to the host!\n");
		return 1;
	}

	if (networkType == 'S')
		RunServer();
	else
		RunClient();

	return 0;
}

SDL_mutex *g_serverDistMutex;
TCPsocket g_serverSocket;
int g_clientCnt = 0;
TCPsocket g_clients[128];

int ProcessClient(void *clientSocket)
{
	char data[256];
	int bytesRead;
	int i;

	while ((bytesRead = SDLNet_TCP_Recv(*(TCPsocket*) clientSocket, data, 256)) > 0) {
		SDL_mutexP(g_serverDistMutex);
		for (i = 0; i < g_clientCnt; ++i) {
			SDLNet_TCP_Send(g_clients[i], data, bytesRead);
		}
		SDL_mutexV(g_serverDistMutex);
	}
	return 0;
}

void RunServer()
{
	g_serverSocket = SDLNet_TCP_Open(&g_currentIP);
	if (g_serverSocket == 0) {
		printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
		exit(1);
	}
	puts("Server successfully started!");
	g_serverDistMutex = SDL_CreateMutex();

	while (1) {
		TCPsocket client = SDLNet_TCP_Accept(g_serverSocket);
		if (client != 0 && g_clientCnt < MAX_CLIENTS) {
			IPaddress *ip;
			int i0,i1,i2,i3;
			printf("A client connected!\n");
			g_clients[g_clientCnt++] = client;
			ip = SDLNet_TCP_GetPeerAddress(client);
			i0 = (ip->host >> 24) & 0xFF;
			i1 = (ip->host >> 16) & 0xFF;
			i2 = (ip->host >> 8) & 0xFF;
			i3 = (ip->host >> 0) & 0xFF;
			printf("the ip: %d.%d.%d.%d\n", i3,i2,i1,i0);
			SDL_CreateThread(ProcessClient, g_clients+g_clientCnt-1);
		}
		SDL_Delay(500);
	}

	SDL_DestroyMutex(g_serverDistMutex);
	puts("Server shut down!");
	SDLNet_TCP_Close(g_serverSocket);
}

SDL_Surface *g_screen, *g_text_surface;
TTF_Font *g_font;
SDL_mutex *g_QMutex, *g_OMutex;
TCPsocket g_clientSocket;

#define QSIZE 1024
char Q[QSIZE];
int Qs, Qe;

char O[QSIZE];
int Os, Oe;

int ReceivePlayerInput(void *data)
{
	while (1) {
		int sz;

		sz = SDLNet_TCP_Recv(g_clientSocket, Q+Qe, 2);
		if (sz != 2) {
			printf("Connection problem!\n");
			exit(1);
		}

		SDL_mutexP(g_QMutex);

		Qe += 2;
		if (Qe == QSIZE)
			Qe = 0;

		SDL_mutexV(g_QMutex);
	}
	return 0;
}

int SendPlayerInput(void *data)
{
	while (1) {
		int sz;
		int tosend = 0;
		SDL_mutexP(g_OMutex);
		if (Os != Oe)
			tosend = 1;
		SDL_mutexV(g_OMutex);

		if (tosend) {
			sz = SDLNet_TCP_Send(g_clientSocket, O+Os, 2);
			if (sz != 2) {
				printf("Connection problem!\n");
				exit(1);
			}
			SDL_mutexP(g_OMutex);
			Os += 2;
			if (Os == QSIZE)
				Os = 0;
			SDL_mutexV(g_OMutex);
		}

		SDL_Delay(5);
	}
	return 0;
}

void RunClient()
{
	SDL_Thread *rpi_th, *spi_th;

	g_screen = SDL_SetVideoMode(800, 600, 24, SDL_HWSURFACE|SDL_DOUBLEBUF);
	if (g_screen == 0) {
		printf("SDL_SetVideMode: %s\n", SDL_GetError());
		exit(1);
	}

	TTF_Init();

	g_font = TTF_OpenFont("DejaVuSansMono.ttf", 12);
	if(!g_font) {
		printf("TTF_OpenFont: %s\n", TTF_GetError());
		exit(1);
	}

	g_clientSocket = SDLNet_TCP_Open(&g_currentIP);
	if (g_clientSocket == 0) {
		printf("SDLNet_TCP_Open: %s\n", SDLNet_GetError());
		exit(1);
	}
	puts("Client successfully connected to the server!");
	g_QMutex = SDL_CreateMutex();
	g_OMutex = SDL_CreateMutex();

	SetUpGameState();

	rpi_th = SDL_CreateThread(ReceivePlayerInput, 0);
	spi_th = SDL_CreateThread(SendPlayerInput, 0);
	while (1) {
		SDL_Event event;
		while (SDL_PollEvent(&event) == 1) {
			if (event.type == SDL_KEYDOWN) {
				int ch = event.key.keysym.sym;
				if (ch >= SDLK_a && ch <= SDLK_z) {
					SDL_mutexP(g_OMutex);
					O[Oe++] = CURRENT_PLAYER;
					O[Oe++] = ch;
					if (Oe == QSIZE)
						Oe = 0;
					SDL_mutexV(g_OMutex);
				} else if (ch == SDLK_F12) {
					goto END_LOOP;
				}
			}
		}

		SDL_mutexP(g_QMutex);
		while (Qs != Qe) {
			int player, button;
			player = Q[Qs++];
			button = Q[Qs++];
			ProcessPlayerInput(player, button);
			if (Qs == QSIZE)
				Qs = 0;
		}
		SDL_mutexV(g_QMutex);

		if (needRendering) {
			needRendering = 0;
			RenderGame();
		}

		SDL_Delay(5);
	}
END_LOOP:

	SDL_KillThread(rpi_th);
	SDL_KillThread(spi_th);
	SDL_DestroyMutex(g_QMutex);
	SDL_DestroyMutex(g_OMutex);
	SDLNet_TCP_Close(g_clientSocket);
	puts("Server connection closed!");

	TTF_CloseFont(g_font);
	TTF_Quit();
}

void RenderGame()
{
	SDL_Color whiteColor = {255,255,255,0};
	SDL_Color silverColor = {100,100,100,0};
	SDL_Color blackColor = {0,0,0,0};
	SDL_Color playerColors[4][3] = {
		{{75,0,0,0},{125,0,0,0},{175,0,0,0}},
		{{0,0,75,0},{0,0,125,0},{0,0,175,0}},
		{{0,75,0,0},{0,125,0,0},{0,175,0,0}},
		{{0xcc,0x90,0x98,0},{0xff,0x69,0xb4,0},{0xff,0x14,0x93,0}},
	};
	SDL_Rect rect;
	int r, c;
	int w = 800 / COLS, h = 600 / ROWS;
	char ch;
	int index;

	/* set the background to black */
	rect.x = 0; rect.y = 0; rect.w = 800; rect.h = 600;
	SDL_FillRect(g_screen, &rect, SDL_MapRGB(g_screen->format,0,0,0));

	/* draw each playfield's background */
	for (r = 0; r < ROWS; ++r) {
		for (c = 0; c < COLS; ++c) {
			int red, green, blue;
			if (g_playerOwnage[r][c] == 0)
				continue;
			rect.x = c*w; rect.y = r*h; rect.w = w-1; rect.h = h-1;
			red = playerColors[g_playerOwnage[r][c]-1][g_fieldStrength[r][c]].r;
			green = playerColors[g_playerOwnage[r][c]-1][g_fieldStrength[r][c]].g;
			blue = playerColors[g_playerOwnage[r][c]-1][g_fieldStrength[r][c]].b;
			SDL_FillRect(g_screen, &rect, SDL_MapRGB(g_screen->format,red,green,blue));
		}
	}

	/* draw the text on the playfields */
	for (r = 0; r < ROWS; ++r) {
		for (c = 0; c < COLS; ++c) {
			g_text_surface = TTF_RenderText_Solid(g_font, g_gameString[r][c], whiteColor);
			rect.x = c*w+w/2-g_text_surface->w/2; rect.y = r*h+h/2-g_text_surface->h/2; rect.w = g_text_surface->w; rect.h = g_text_surface->h;
			SDL_BlitSurface(g_text_surface, 0, g_screen, &rect);
			SDL_FreeSurface(g_text_surface);

			index = g_playerPositions[r][c][CURRENT_PLAYER];
			ch = g_gameString[r][c][index];
			g_gameString[r][c][index] = 0;
			g_text_surface = TTF_RenderText_Solid(g_font, g_gameString[r][c], silverColor);
			SDL_BlitSurface(g_text_surface, 0, g_screen, &rect);
			SDL_FreeSurface(g_text_surface);
			g_gameString[r][c][index] = ch;
		}
	}

	SDL_Flip(g_screen);
}

int isPlayersField(int player, int r, int c)
{
	if (r < 0 || c < 0 || r >= ROWS || c >= COLS)
		return 0;
	return (g_playerOwnage[r][c] == player+1);
}

void ProcessPlayerInput(int player, int ch)
{
	int r, c;
	for (r = 0; r < ROWS; ++r) {
		for (c = 0; c < COLS; ++c) {
			int index;
			if (!isPlayersField(player,r,c) && !isPlayersField(player,r-1,c) && !isPlayersField(player,r,c-1) && !isPlayersField(player,r+1,c) && !isPlayersField(player,r,c+1))
				continue;
			index = g_playerPositions[r][c][player];
			if (ch == g_gameString[r][c][index]) {
				index += 1;
				if (index == strlen(g_gameString[r][c])) {
					int ishis = (g_playerOwnage[r][c] == player+1);
					index = 0;

					if (ishis && g_fieldStrength[r][c] < 2) {
						g_fieldStrength[r][c] += 1;
					} else if (!ishis) {
						if (g_fieldStrength[r][c] > 0)
							g_fieldStrength[r][c] -= 1;
						else
							g_playerOwnage[r][c] = player+1;
					}
				}
				g_playerPositions[r][c][player] = index;
			}
		}
	}
	needRendering = 1;
}

char g_wordlist[1000][MAX_GAMESTRING_LEN+1];
int g_wordlistSize;

int next_rand()
{
	static int a = 24323, b = 13143, xn = 12317, m = 53213;
	xn = (a*xn + b) % m;
	return xn;
}

void SetUpGameState()
{
	int i, r, c;
	FILE *f;
	f = fopen("words.eng", "r");
	if (!f) {
		printf("Couldn't open words.eng!\n");
		exit(1);
	}

	for (i = 0; i < 1000 && fscanf(f, "%s", g_wordlist[i]) == 1; ++i) {
		if (strlen(g_wordlist[i]) > 8)
			i -= 1;
	}
	g_wordlistSize = i;
	fclose(f);

	for (r = 0; r < ROWS; ++r) {
		for (c = 0; c < COLS; ++c) {
			strcpy(g_gameString[r][c], g_wordlist[next_rand()%i]);
		}
	}

	g_playerOwnage[0][0] = 2;
	g_fieldStrength[0][0] = 1;
	g_playerOwnage[ROWS-1][COLS-1] = 1;
	g_fieldStrength[ROWS-1][COLS-1] = 1;
	g_playerOwnage[0][COLS-1] = 3;
	g_fieldStrength[0][COLS-1] = 1;
	g_playerOwnage[ROWS-1][0] = 4;
	g_fieldStrength[ROWS-1][0] = 1;
}
