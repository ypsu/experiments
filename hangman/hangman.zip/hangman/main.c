#include <assert.h>
#include <stdbool.h>
#include <stdio.h>
#include <time.h>
#include <SDL/SDL.h>
#include <SDL/SDL_net.h>
#include <SDL/SDL_thread.h>
#include <SDL/SDL_ttf.h>

#define MAX_WORDS 123456
#define MAX_WORD_LENGTH 32
#define LIVES 10
#define MAX_PLAYERS 4
#define MAX_HOSTNAME 64
#define MAX_ERROR_MESSAGE 256

SDL_Surface *g_sdl_surface;
SDL_Surface *g_pics[LIVES];
TTF_Font *g_font;
SDL_Color BLACK;
SDL_Color WHITE = {.r = 255, .g = 255, .b = 255};
SDL_Color YELLOW = {.r = 255, .g = 255, .b = 0};
int g_char_widths[128];
bool g_letter_used[128];
SDL_Color g_letter_colors[128];
int g_letter_widthsum;
int g_font_height;

int g_word_length;
int g_word_widthsum;
char g_word[MAX_WORD_LENGTH+1];
char g_printed_word[MAX_WORD_LENGTH+1];

int g_words_count;
char g_words[MAX_WORDS][MAX_WORD_LENGTH+1];

SDL_Color g_player_colors[MAX_PLAYERS] = {
	{.r = 0, .g = 255, .b = 255},
	{.r = 255, .g = 255, .b = 0},
	{.r = 0, .g = 255, .b = 0},
	{.r = 255, .g = 0, .b = 0},
};
int g_player_colormaps[MAX_PLAYERS] = {6, 3, 2, 1};

int g_current_player;
int g_player_state[MAX_PLAYERS];
int g_player_score[MAX_PLAYERS];
bool g_player_ready[MAX_PLAYERS];

bool g_enter_needed_to_continue;
bool g_repaint_needed;

int g_round_count = 10;
int g_current_round;

enum {
	STATE_MENU,
	STATE_ENTER_HOST,
	STATE_ENTER_PORT,
	STATE_ERROR,
	STATE_LOBBY,
	STATE_GAME,
} g_game_state;

char g_error_message[MAX_ERROR_MESSAGE+1];
char g_hostname[MAX_HOSTNAME + 1] = "localhost";
int g_port = 3467;
int g_player_count;

SDLNet_SocketSet g_server_socket_set;
TCPsocket g_server_socket;

enum net_command {
	NETCMD_SET_PLAYER_COUNT,
	NETCMD_SET_PLAYER_ID,
	NETCMD_MARK_READY,
	NETCMD_SERVER_JOINS_DONE,
	NETCMD_NEXT_ROUND, // parameter = word id
	NETCMD_PLAYER_KEY, // parameter = (player_id << 8) + key
};

// Hack: SDLNet_TCP_Recv isn't conforming to its documentation
// (documentation retrieved in 2012 January, bug reported)
int recv_all(TCPsocket socket, void *buffer, int sz)
{
	int read = 0;
	int rem = sz;
	while (rem > 0 && (read = SDLNet_TCP_Recv(socket, buffer, rem)) > 0) {
		buffer += read;
		rem -= read;
	}
	if (read == -1)
		return -1;
	return sz - rem;
}

void distribute_buffer(TCPsocket *sockets, int socket_count, const char *data, int length)
{
	for (int i = 0; i < socket_count; ++i) {
		int res = SDLNet_TCP_Send(sockets[i], data, length);
		assert(res == length);
	}
}

void distribute_message(TCPsocket *sockets, int socket_count, int command, int parameter)
{
	char msg[4];
	SDLNet_Write32(command + (parameter << 8), msg);
	distribute_buffer(sockets, socket_count, msg, 4);
}

int server_thread(void *unused)
{
	int peer_count = 0;
	int res;

	(void) unused;
	IPaddress ip;
	TCPsocket server;
	TCPsocket peers[MAX_PLAYERS];
	if (SDLNet_ResolveHost(&ip, NULL, g_port) == -1) {
		printf("SDLNet_ResolveHost: %s\n", SDLNet_GetError());
		exit(1);
	}
	server = SDLNet_TCP_Open(&ip);
	if (server == NULL) {
		printf("Unable to listen on %s:%d, error: %s\n",
				g_hostname, g_port, SDLNet_GetError());
		exit(1);
	}
	puts("server started");

	SDLNet_SocketSet set;
	set = SDLNet_AllocSocketSet(5);
	assert(set != NULL);
	res = SDLNet_TCP_AddSocket(set, server);
	assert(res == 1);

	bool in_join_phase = true;

	while (true) {
		int res = SDLNet_CheckSockets(set, -1);
		assert(res != -1);
		for (int i = 0; i < peer_count; ++i) {
			TCPsocket s = peers[i];
			if (SDLNet_SocketReady(s) == 0) continue;
			char send_buf[128];
			int length = 0;
			do {
				int msg, cmd;
				int recvd = recv_all(s, send_buf+length, 4);
				if (recvd != 4) {
					printf("Connection closed!\n");
					exit(0);
				}
				msg = SDLNet_Read32(send_buf+length);
				length += 4;
				cmd = msg & 0xff;
				if (cmd == NETCMD_SERVER_JOINS_DONE && in_join_phase) {
					puts("joins done");
					in_join_phase = false;
					SDLNet_TCP_DelSocket(set, server);
				}
				SDLNet_CheckSockets(set, 0);
			} while (SDLNet_SocketReady(s) && length < 100);
			distribute_buffer(peers, peer_count, send_buf, length);
		}

		if (in_join_phase) {
			if (SDLNet_SocketReady(server) != 0) {
				puts("a player joined");
				TCPsocket s = SDLNet_TCP_Accept(server);
				assert(s != NULL);
				if (peer_count == MAX_PLAYERS) {
					SDLNet_TCP_Close(s);
					continue;
				}
				peers[peer_count++] = s;
				res = SDLNet_TCP_AddSocket(set, s);
				assert(res != -1);
				int cmd = NETCMD_SET_PLAYER_COUNT;
				distribute_message(&s, 1, NETCMD_SET_PLAYER_ID, peer_count-1);
				distribute_message(peers, peer_count, cmd, peer_count);
			}
		}

	}

	SDLNet_TCP_Close(server);
	return 0;
}

// x = -1 => center the text
// x = -2 => right align the text
void print_text(int x, int y, SDL_Color color, const char *buf)
{
	if (x == -1) {
		int res;
		int w;
		res = TTF_SizeUTF8(g_font, buf, &w, NULL);
		assert(res == 0);
		x = 400 - w/2;
	}
	if (x == -2) {
		int res;
		int w;
		res = TTF_SizeUTF8(g_font, buf, &w, NULL);
		assert(res == 0);
		x = 800 - w;
	}

	SDL_Surface *text_surface;
	text_surface = TTF_RenderUTF8_Shaded(g_font, buf, color, BLACK);
	SDL_Rect dst = {.x = x, .y = y};
	SDL_BlitSurface(text_surface, NULL, g_sdl_surface, &dst);
	SDL_FreeSurface(text_surface);
}

void set_error(const char *message)
{
	g_game_state = STATE_ERROR;
	assert(strlen(message) < MAX_ERROR_MESSAGE);
	strcpy(g_error_message, message);

	g_repaint_needed = true;
}

bool join_server(void)
{
	IPaddress ip;
	if (SDLNet_ResolveHost(&ip, g_hostname, g_port) == -1) {
		char error[256];
		sprintf(error, "Error: %s", SDLNet_GetError());
		set_error(error);
		return false;
	}

	g_server_socket = SDLNet_TCP_Open(&ip);
	if (g_server_socket == NULL) {
		char error[256];
		sprintf(error, "Error: %s", SDLNet_GetError());
		set_error(error);
		return false;
	}

	g_server_socket_set = SDLNet_AllocSocketSet(1);
	assert(g_server_socket_set != NULL);
	int res = SDLNet_TCP_AddSocket(g_server_socket_set, g_server_socket);
	assert(res == 1);

	g_game_state = STATE_LOBBY;

	return true;
}

void render_alphabet(void)
{
	int pos = 400 - (g_letter_widthsum + 25*g_char_widths[' '])/2;
	for (int i = 0; i < 26; ++i) {
		char buf[2] = {};
		buf[0] = 'a' + i;
		print_text(pos, 550, g_letter_colors['a'+i], buf);
		pos += g_char_widths['a' + i] + g_char_widths[' '];
	}
}

void render_word(void)
{
	int pos = 400 - (g_word_widthsum + (g_word_length-1)*g_char_widths[' '])/2;
	for (int i = 0; i < g_word_length; ++i) {
		int ch = g_printed_word[i];
		char buf[2] = {};
		buf[0] = ch;
		print_text(pos, 500, g_letter_colors[ch], buf);
		pos += g_char_widths[ch] + g_char_widths[' '];
	}
}

void render_stats(void)
{
	char game[64];
	sprintf(game, "Round: %2d / %2d", g_current_round, g_round_count);
	print_text(0, 0, WHITE, game);

	char score[64];
	for (int i = 0; i < g_player_count; ++i) {
		sprintf(score, "%3d", g_player_score[i]);
		print_text(0, (i+1)*g_font_height, g_player_colors[i], score);
	}
}

void init_sdl(void)
{
	SDL_Init(SDL_INIT_VIDEO);
	g_sdl_surface = SDL_SetVideoMode(800, 600, 32, SDL_DOUBLEBUF);
	assert(g_sdl_surface != NULL);
	assert(g_sdl_surface->pitch == 800*4);
	SDL_WM_SetCaption("Hangman", "Hangman");
	SDL_EnableUNICODE(1);
	if (TTF_Init() == -1) {
		printf("TTF_Init: %s\n", TTF_GetError());
		exit(1);
	}
	g_font = TTF_OpenFont("vera.ttf", 24);
	assert(g_font != NULL);
	if (SDLNet_Init() == -1) {
		printf("SDLNet_Init: %s\n", SDLNet_GetError());
		exit(1);
	}
}

void calc_font_widths(void)
{
	for (unsigned char ch = 32; ch < 128; ++ch) {
		char buf[2] = {};
		buf[0] = ch;
		int res, w;
		res = TTF_SizeUTF8(g_font, buf, &w, NULL);
		assert(res == 0);
		g_char_widths[(int) ch] = w;
	}
	
	for (int ch = 'a'; ch <= 'z'; ++ch)
		g_letter_widthsum += g_char_widths[ch];

	g_font_height = TTF_FontLineSkip(g_font);
}

void init_game(int word_id)
{
	g_enter_needed_to_continue = false;
	memset(g_player_ready, 0, sizeof g_player_ready);
	if (g_current_round == g_round_count) {
		g_current_round = 0;
		g_enter_needed_to_continue = true;
		return;
	}
	if (g_current_round == 0) {
		memset(g_player_score, 0, sizeof g_player_score);
	}
	g_current_round += 1;

	for (int ch = 32; ch < 128; ++ch) {
		g_letter_colors[ch] = WHITE;
	}

	strcpy(g_word, g_words[word_id]);
	g_word_length = (int) strlen(g_word);

	g_word_widthsum = 0;
	for (int i = 0; i < g_word_length; ++i) {
		g_word_widthsum += g_char_widths[(int) g_word[i]];
		g_printed_word[i] = '_';
	}

	memset(g_letter_used, 0, sizeof g_letter_used);
	memset(g_player_state, 0, sizeof g_player_state);

	g_game_state = STATE_GAME;

	g_repaint_needed = true;
}

void read_words(void)
{
	FILE *f = fopen("words.txt", "r");
	assert(f != NULL);
	assert(MAX_WORD_LENGTH == 32);
	while (fscanf(f, "%32s", g_words[g_words_count]) == 1) {
		for (char *p = g_words[g_words_count]; *p != 0; ++p) {
			if (!islower(*p)) {
				puts("Only lowercase English letters are supported!");
				exit(1);
			}
		}

		g_words_count += 1;
		if (g_words_count >= MAX_WORDS) {
			printf("Only %d words can be in a dictionary!\n", MAX_WORDS-1);
			exit(1);
		}
	}
	fclose(f);
}

void handle_key_from_player(int player, int ch)
{
	if (ch < 'a' || ch  > 'z') return;
	if (g_letter_used[ch]) return;
	if (g_player_state[player] >= 9) return;

	g_letter_used[ch] = true;
	g_letter_colors[ch] = g_player_colors[player];
	bool found = false;
	for (int i = 0; i < g_word_length; ++i) {
		if (g_word[i] == ch) {
			g_player_score[player] += 1;
			g_printed_word[i] = ch;
			found = true;
		}
	}

	if (!found) {
		g_player_state[player] += 1;
		g_player_score[player] -= 1;
		if (g_player_state[player] >= 9) {
			strcpy(g_printed_word, g_word);
		}
	}

	if (strchr(g_printed_word, '_') == NULL) {
		g_enter_needed_to_continue = true;
	}
}

void handle_keypress_in_game(const SDL_keysym *key)
{
	if (key->sym == 27) exit(0);

	if (g_enter_needed_to_continue || g_player_ready[g_current_player]) {
		if (!g_player_ready[g_current_player] && key->sym == 13) {
			int cmd = NETCMD_MARK_READY;
			distribute_message(&g_server_socket, 1, cmd, g_current_player);
		}
		return;
	}

	int ch = key->unicode;
	if (ch < 'a' || ch  > 'z') return;
	int parameter = (g_current_player << 8) + ch;
	distribute_message(&g_server_socket, 1, NETCMD_PLAYER_KEY, parameter);
}

void handle_keypress_in_menu(const SDL_keysym *key)
{
	if (g_game_state == STATE_MENU && key->sym == 27) exit(0);

	if (g_game_state == STATE_ERROR) {
		g_game_state = STATE_MENU;
		return;
	}

	if (g_game_state == STATE_ENTER_HOST && (key->sym == 27 || key->sym == 13)) {
		g_game_state = STATE_MENU;
		return;
	}
	if (g_game_state == STATE_ENTER_PORT && (key->sym == 27 || key->sym == 13)) {
		g_game_state = STATE_MENU;
		return;
	}

	if (g_game_state == STATE_ENTER_HOST && key->sym == 8) {
		int zero_idx;
		for (zero_idx = 0; g_hostname[zero_idx] != 0; ++zero_idx)
			;
		if (zero_idx > 0) g_hostname[zero_idx-1] = 0;
		return;
	}

	if (g_game_state == STATE_ENTER_PORT && key->sym == 8) {
		g_port /= 10;
		return;
	}

	int ch = key->unicode;
	if (g_game_state == STATE_MENU && ch == 'n') {
		g_game_state = STATE_ENTER_HOST;
	} else if (g_game_state == STATE_MENU && ch == 'p') {
		g_game_state = STATE_ENTER_PORT;
	} else if (g_game_state == STATE_MENU && ch == 'h') {
		puts("hosting");
		SDL_Thread *thread;
		thread = SDL_CreateThread(server_thread, NULL);
		assert(thread != NULL);
		SDL_Delay(200); // wait until the server starts
		puts("joining");
		join_server();
	} else if (g_game_state == STATE_MENU && ch == 'j') {
		puts("joining");
		join_server();
	} else if (g_game_state == STATE_ENTER_HOST) {
		char buf[2] = { ch, 0 };
		if (strlen(g_hostname) < MAX_HOSTNAME) {
			strcat(g_hostname, buf);
		}
	} else if (g_game_state == STATE_ENTER_PORT && isdigit(ch)) {
		int nport = g_port*10 + (ch - '0');
		if (nport < 65536) g_port = nport;
	}
}

void handle_keypress_in_lobby(const SDL_keysym *key)
{
	if (key->sym == 27) exit(0);
	if (key->sym == 13) {
		distribute_message(&g_server_socket, 1, NETCMD_MARK_READY, g_current_player);
	}
}

void handle_keypress(const SDL_keysym *key)
{
	if (g_game_state == STATE_GAME) {
		handle_keypress_in_game(key);
	} else if (g_game_state == STATE_LOBBY) {
		handle_keypress_in_lobby(key);
	} else {
		handle_keypress_in_menu(key);
	}

	g_repaint_needed = true;
}

void load_pics(void)
{
	for (int i = 0; i < LIVES; ++i) {
		char fname[64];
		sprintf(fname, "pics/%d.bmp", i+1);
		g_pics[i] = SDL_LoadBMP(fname);
		assert(g_pics[i] != NULL);
		assert(g_pics[i]->w == 200);
		assert(g_pics[i]->h == 200);
		assert(g_pics[i]->pitch == 200*3);
	}
}

void display_hangman(int x, int y, int pic, int colors)
{
	int res;
	res = SDL_LockSurface(g_sdl_surface);
	assert(res == 0);
	res = SDL_LockSurface(g_pics[pic]);
	assert(res == 0);

	uint32_t *screen = g_sdl_surface->pixels;
	unsigned char *picture = g_pics[pic]->pixels;
	for (int yy = y; yy < y+200; ++yy) {
		for (int xx = x; xx < x+200; ++xx) {
			uint32_t *s = screen + yy*800 + xx;
			unsigned char *p = picture + (yy-y)*200*3 + (xx-x)*3;
			uint32_t c = 0;
			if (colors & 1) c += *(p+0) << 16;
			if (colors & 2) c += *(p+1) << 8;
			if (colors & 4) c += *(p+2);
			*s = c;
		}
	}

	SDL_UnlockSurface(g_pics[pic]);
	SDL_UnlockSurface(g_sdl_surface);
}

void render_enter_to_continue(void)
{
	if (g_enter_needed_to_continue) {
		if (g_player_ready[g_current_player]) {
			print_text(-1, 0, WHITE, "waiting for other players");
		} else {
			print_text(-1, 0, WHITE, "press ENTER when ready");
		}
	}
}

void render_current_player_id(void)
{
	char buf[64];
	sprintf(buf, "P%d", g_current_player);
	print_text(-2, 0, g_player_colors[g_current_player], buf);
}

void render_game(void)
{
	if (g_current_round == 0) {
		SDL_PixelFormat *format = g_sdl_surface->format;
		SDL_FillRect(g_sdl_surface, NULL, SDL_MapRGB(format, 0, 0, 0));
		render_stats();
		render_current_player_id();
		render_enter_to_continue();

		print_text(-1, 290, WHITE, "GAME OVER!");
		char buf[64];
		int best_player = 0;
		for (int i = 1; i < g_player_count; ++i) {
			if (g_player_score[best_player] < g_player_score[i])
				best_player = i;
		}
		sprintf(buf, "PLAYER %d WINS!", best_player);
		print_text(-1, 290+g_font_height, g_player_colors[best_player], buf);
		print_text(-1, 290+2*g_font_height, WHITE, "PRESS ENTER TO RESTART!");
		print_text(-1, 290+3*g_font_height, WHITE, "PRESS ESCAPE TO QUIT!");

		SDL_Flip(g_sdl_surface);
		return;
	}

	render_alphabet();
	render_word();
	render_stats();
	render_current_player_id();
	render_enter_to_continue();

	if (g_player_count>=1) display_hangman(100,  50, g_player_state[0], g_player_colormaps[0]);
	if (g_player_count>=2) display_hangman(500,  50, g_player_state[1], g_player_colormaps[1]);
	if (g_player_count>=3) display_hangman(100, 300, g_player_state[2], g_player_colormaps[2]);
	if (g_player_count>=4) display_hangman(500, 300, g_player_state[3], g_player_colormaps[3]);
}

void render_lobby()
{
	char buffer[64];

	if (g_player_ready[g_current_player]) {
		print_text(-1, 0, WHITE, "waiting for other players");
	} else {
		print_text(-1, 0, WHITE, "press ENTER when ready");
	}

	int h = g_font_height;
	print_text(-1, 200, WHITE, "THE LOBBY");
	for (int i = 0; i < g_player_count; ++i) {
		if (g_player_ready[i]) {
			sprintf(buffer, "player %d ready", i);
		} else {
			sprintf(buffer, "player %d waiting", i);
		}
		print_text(-1, 200+(i+2)*h, g_player_colors[i], buffer);
	}

	sprintf(buffer, "you are player %d", g_current_player);
	print_text(-2, 0, g_player_colors[g_current_player], buffer);
}

void render_error(void)
{
	print_text(-1, 290, WHITE, g_error_message);
}

void render_menu(void)
{
	char buf[128 + MAX_HOSTNAME];
	int h = g_font_height;
	print_text(-1, 200 + 0*h, WHITE, "Host game");
	print_text(-1, 200 + 1*h, WHITE, "Join game");

	if (g_game_state == STATE_ENTER_HOST) {
		sprintf(buf, "=> hostName: %s| <=", g_hostname);
		print_text(-1, 200 + 3*h, YELLOW, buf);
	} else {
		sprintf(buf, "hostName: %s ", g_hostname);
		print_text(-1, 200 + 3*h, WHITE, buf);
	}

	if (g_game_state == STATE_ENTER_PORT) {
		sprintf(buf, "=> Port: %d| <=", g_port);
		print_text(-1, 200 + 4*h, YELLOW, buf);
	} else {
		sprintf(buf, "Port: %d ", g_port);
		print_text(-1, 200 + 4*h, WHITE, buf);
	}

	print_text(-1, 500, WHITE, "Press j, h, n or p!");
}

void handle_server_events(void)
{
	if (!(g_game_state == STATE_LOBBY || g_game_state == STATE_GAME)) return;

	SDLNet_CheckSockets(g_server_socket_set, 0);
	while (SDLNet_SocketReady(g_server_socket) != 0) {
		g_repaint_needed = true;
		int32_t msg;
		int res = recv_all(g_server_socket, &msg, 4);
		if (res != 4) {
			puts("Connection closed!");
			exit(1);
		}
		SDLNet_CheckSockets(g_server_socket_set, 0);

		msg = SDLNet_Read32(&msg);
		int cmd = msg & 0xFF;
		int parameter = msg >> 8;
		if (cmd == NETCMD_SET_PLAYER_COUNT) {
			g_player_count = parameter;
		} else if (cmd == NETCMD_SET_PLAYER_ID) {
			g_current_player = parameter;
		} else if (cmd == NETCMD_MARK_READY) {
			g_player_ready[parameter] = true;
			if (g_current_player == 0) {
				int ready_count = 0;
				for (int i = 0; i < g_player_count; ++i) {
					if (g_player_ready[i])
						ready_count += 1;
				}
				if (ready_count == g_player_count) {
					int cmd, par;

					cmd = NETCMD_SERVER_JOINS_DONE;
					distribute_message(&g_server_socket, 1, cmd, 0);

					cmd = NETCMD_NEXT_ROUND;
					srand(time(NULL));
					par = rand() % g_words_count;
					distribute_message(&g_server_socket, 1, cmd, par);
				}
			}
		} else if (cmd == NETCMD_NEXT_ROUND) {
			init_game(parameter);
		} else if (cmd == NETCMD_PLAYER_KEY) {
			handle_key_from_player(parameter>>8, parameter&0xFF);
		}
	}
}

#undef main
int main()
{
	init_sdl();
	calc_font_widths();
	read_words();
	load_pics();

	g_repaint_needed = true;
	while (true) {
		SDL_Event event;
		while (SDL_PollEvent(&event) == 1) {
			if (event.type == SDL_QUIT) {
				exit(0);
			} else if (event.type == SDL_KEYDOWN) {
				handle_keypress(&event.key.keysym);
			}
		}
		handle_server_events();
		if (g_repaint_needed) {
			SDL_PixelFormat *format = g_sdl_surface->format;
			SDL_FillRect(g_sdl_surface, NULL, SDL_MapRGB(format, 0, 0, 0));

			if (g_game_state == STATE_GAME) {
				render_game();
			} else if (g_game_state == STATE_ERROR) {
				render_error();
			} else if (g_game_state == STATE_LOBBY) {
				render_lobby();
			} else {
				render_menu();
			}

			g_repaint_needed = false;
			SDL_Flip(g_sdl_surface);
		}

		SDL_Delay(1);
	}

	return 0;
}
